package demo.javahero.demospringbootjavahero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemospringbootjavaheroApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemospringbootjavaheroApplication.class, args);
	}

}
